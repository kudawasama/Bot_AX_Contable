# Design System Document: 2026 Enterprise Professional

## 1. Overview & Creative North Star: "The Kinetic Executive"
The Creative North Star for this design system is **"The Kinetic Executive."** We are moving away from the static, "boxed-in" nature of traditional enterprise software. This system captures the raw, technical power of a command-line engine (the 'Gemini CLI' heritage) and encases it in a high-end, editorial shell. 

To achieve this, we reject the rigid grid in favor of **Intentional Asymmetry**. We use extreme typographic contrast and overlapping "frosted" layers to create a sense of depth and motion. The UI should feel like a precision instrument—sharp, responsive, and deceptively simple, while hiding immense computational power beneath its obsidian surface.

---

## 2. Colors & Surface Philosophy
The palette is rooted in a deep, obsidian foundation (`#131314`) to provide a high-contrast stage for electric blue (`primary`) and refined violet (`secondary`) accents.

### The "No-Line" Rule
**Standard 1px solid borders are strictly prohibited for sectioning.** 
Structural boundaries must be defined exclusively through background shifts. For example, a dashboard sidebar should use `surface_container_low` against a `surface` main content area. If you feel the urge to draw a line, use a 24px (5.5rem) gap instead.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-translucent materials.
- **Base Layer:** `surface` (#131314) for the main application background.
- **Secondary Regions:** `surface_container_low` or `surface_container` for secondary navigation or utility panels.
- **Active Workspace:** `surface_container_high` for primary interactive zones.
- **The "Glass & Gradient" Signature:** Floating modals or high-priority overlays must use `surface_container_highest` with a 12px backdrop blur and 80% opacity. 

### Signature Textures
Main CTAs and Hero moments should utilize a **Linear Kinetic Gradient**:
- Transition from `primary` (#b7c4ff) to `primary_container` (#0052ff) at a 135-degree angle. This provides a "pulsing" energy that flat colors cannot replicate.

---

## 3. Typography: The Editorial Scale
We use a dual-font strategy to balance technical precision with executive authority. **Manrope** is used for high-impact display and headlines, while **Inter** handles the dense, data-heavy "engine" work.

- **Display-LG (Manrope, 3.5rem):** Reserved for singular, high-impact data points or welcome states. Use `on_surface` color with -0.02em letter spacing.
- **Headline-MD (Manrope, 1.75rem):** Used for section titles. Pair this with a `primary` color accent to draw the eye.
- **Body-MD (Inter, 0.875rem):** The workhorse for all technical data and descriptions. Ensure a line-height of 1.5 to maintain the "premium" feel.
- **Label-SM (Inter, 0.6875rem):** All-caps, tracked out +5% for metadata and technical "CLI-style" tags.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "heavy" for a 2026 aesthetic. We achieve lift through light and transparency.

### The Layering Principle
Depth is created by nesting surface tokens. 
- *Rule:* An inner container must always be at least one tier "brighter" or "dimmer" than its parent. 
- Example: Place a `surface_container_lowest` card inside a `surface_container_low` section to create a "recessed" technical dock look.

### Ambient Shadows
If a "Floating" state is required (e.g., a command palette):
- **Shadow:** `0px 24px 48px rgba(0, 0, 0, 0.4)`. 
- **The Ghost Border:** Instead of a solid line, use a 1px border of `outline_variant` (#434656) at **15% opacity**. This creates a "glint" on the edge of the glass rather than a physical containment line.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`). `xl` (0.75rem) roundedness. Text is `on_primary_fixed_variant`.
- **Secondary:** Surface-only. No border. Use `surface_container_highest` background with `primary` text.
- **Tertiary:** Transparent background. `primary` text. On hover, apply a `surface_bright` ghost-fill at 10% opacity.

### The "CLI" Input Field
- **Base:** Background `surface_container_low`. 
- **Indicator:** Instead of a full-box focus ring, use a 2px vertical "power bar" on the left edge in `tertiary` (#89ceff) when active.
- **Text:** `body-md` in `on_surface`.

### Cards & Data Lists
- **Rule:** Forbid divider lines. 
- Use the **Spacing Scale `10` (2.25rem)** to separate list items. 
- To highlight a selected row, change the background to `surface_container_high` and apply an `xl` corner radius.

### Signature Component: The "Status Glint"
For executive dashboards, use small, high-chroma `tertiary` or `secondary` chips with a `surface_tint` outer glow (blur: 8px) to indicate live technical processes.

---

## 6. Do’s and Don’ts

### Do:
- **Use Asymmetric Padding:** Try a `spacing-16` (3.5rem) top padding and `spacing-8` (1.75rem) side padding for headers to create an editorial look.
- **Embrace "Dark Matter":** Use large areas of `surface_container_lowest` to let the "Electric Blue" accents pop.
- **Layer Glass:** Stack a glassmorphic sidebar over a blurred background image for "Premium Executive" depth.

### Don’t:
- **Don't use #000000:** It kills the depth. Always use `surface` (#131314).
- **Don't use 100% Opaque Borders:** This shatters the "glassmorphism" illusion. Always use Ghost Borders (low opacity).
- **Don't Crowded the Data:** This is a tool for executives. If a screen feels "busy," increase your spacing scale by two increments across the board.